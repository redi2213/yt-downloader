"""Composition root for YT Bridge Git.

This module's only job is to build the Kivy application shell (window,
scroll view, content container) and hand control to the Navigator, which
is where screen flow and app-level state actually live. No download,
upload, playlist, or GitHub logic belongs here - see ``services`` and
``api.github`` for that.
"""
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView

import os

from screens import style
from screens.common import GAP, PAD
from screens.navigator import Navigator


class YTBridgeApp(App):
    def build(self):
        Window.softinput_mode = "below_target"
        # Theme, font, size and Persian texts for every widget made from here on.
        style.install(os.path.join(self.user_data_dir, "ui"))

        self.scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", padding=PAD, spacing=GAP, size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        # Placeholder until a screen replaces it with its own status label.
        self.status_label = Label(text="")

        self.nav = Navigator(self)
        self.nav.show_home()
        # The phone's own Back key (key code 27) goes one screen back.
        Window.bind(on_keyboard=self._on_keyboard)
        return self.scroll

    def _on_keyboard(self, window, key, *args):
        if key == 27:
            # True = handled here; False on the home screen = default (close the app)
            return bool(self.nav.go_back())
        return False

    def on_start(self):
        # Links shared into the app from other apps (Android Share menu).
        # No-op on desktop or if the Android hooks are unavailable.
        from core import android_share
        android_share.setup(self.nav.handle_shared_text, self.nav.handle_shared_file)

    def clear_content(self):
        self.content.clear_widgets()

    def add_widget_to_content(self, widget):
        self.content.add_widget(widget)


if __name__ == "__main__":
    YTBridgeApp().run()
